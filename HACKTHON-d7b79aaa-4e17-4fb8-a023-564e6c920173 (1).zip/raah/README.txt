RAAH - chalane ka tarika (Windows, VS Code)

1. Is folder ko VS Code me kholo.
2. Terminal me:   python -m pip install flask
3. Phir:          python app.py
4. Browser me kholo: http://127.0.0.1:5000

AI helper (optional):
- Bina key ke bhi chalta hai, tab basic jawab dikhte hain.
- Asli AI chahiye to apni Anthropic API key lo aur terminal me PEHLE ye likho (key kisi ko mat dikhana, code me mat likhna):
    $env:ANTHROPIC_API_KEY="yahan-apni-key"
  Uske baad python app.py chalao.

Database: raah.db apne aap ban jata hai (SQLite). Isme sirf report ID, category, platform, chhota note aur status hota hai. Koi naam ya number nahi.
