import os, re, json, sqlite3, secrets, urllib.request
from datetime import datetime
from flask import Flask, request, jsonify

app = Flask(__name__, static_folder="static", static_url_path="")
DB = os.path.join(os.path.dirname(os.path.abspath(__file__)), "raah.db")

CATEGORIES = ["blackmail", "morph", "stalk", "fake", "other"]
STATUSES = ["prepared", "sent", "replied", "removed", "escalated"]


def db():
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row
    return con


def init_db():
    with db() as con:
        con.executescript("""
        CREATE TABLE IF NOT EXISTS reports(
            tid TEXT PRIMARY KEY, category TEXT, platform TEXT,
            note TEXT, status TEXT, created TEXT);
        CREATE TABLE IF NOT EXISTS updates(
            id INTEGER PRIMARY KEY AUTOINCREMENT, tid TEXT,
            status TEXT, note TEXT, created TEXT);
        """)


def now():
    return datetime.now().strftime("%Y-%m-%d %H:%M")


@app.route("/")
def home():
    return app.send_static_file("index.html")


# ---------- Report tracking (koi naam/number save nahi hota) ----------
@app.post("/api/reports")
def create_report():
    d = request.get_json(force=True, silent=True) or {}
    category = d.get("category") if d.get("category") in CATEGORIES else "other"
    platform = str(d.get("platform", ""))[:40]
    note = str(d.get("note", ""))[:300]
    tid = "RAAH-" + secrets.token_hex(3).upper()
    with db() as con:
        con.execute("INSERT INTO reports VALUES (?,?,?,?,?,?)",
                    (tid, category, platform, note, "prepared", now()))
        con.execute("INSERT INTO updates(tid,status,note,created) VALUES (?,?,?,?)",
                    (tid, "prepared", "", now()))
    return jsonify(tid=tid)


def report_json(tid):
    with db() as con:
        r = con.execute("SELECT * FROM reports WHERE tid=?", (tid,)).fetchone()
        if not r:
            return None
        ups = con.execute("SELECT status,note,created FROM updates WHERE tid=? ORDER BY id", (tid,)).fetchall()
    return {**dict(r), "history": [dict(u) for u in ups]}


@app.get("/api/reports/<tid>")
def get_report(tid):
    r = report_json(tid.upper())
    return (jsonify(r), 200) if r else (jsonify(error="not_found"), 404)


@app.post("/api/reports/<tid>/update")
def update_report(tid):
    tid = tid.upper()
    d = request.get_json(force=True, silent=True) or {}
    status = d.get("status")
    if status not in STATUSES:
        return jsonify(error="bad_status"), 400
    if not report_json(tid):
        return jsonify(error="not_found"), 404
    with db() as con:
        con.execute("UPDATE reports SET status=? WHERE tid=?", (status, tid))
        con.execute("INSERT INTO updates(tid,status,note,created) VALUES (?,?,?,?)",
                    (tid, status, str(d.get("note", ""))[:200], now()))
    return jsonify(report_json(tid))


# ---------- AI helper: AI sirf baat karta hai, rasta hamare pakke jawab batate hain ----------
INTENTS = ["blackmail", "morph", "stalk", "fake", "anonymous", "track", "danger", "unclear"]

SYSTEM = """You are the warm, friendly helper inside Raah, a safe-reporting guide for women facing online harassment in India. You are an AI. Never claim to be human; if asked, say you are an AI helper.
You do NOT give steps, laws, links or phone numbers: the app adds verified steps itself. Your job: listen, reply with warmth like a caring friend, and work out what the person needs.
Reply with ONLY a JSON object: {"intent": "...", "message": "...", "question": "..."}
- intent: one of blackmail, morph, stalk, fake, anonymous, track, danger, unclear
- message: 1-2 short caring sentences in LANG. No steps, no legal advice, no numbers, no links, never guess who is guilty.
- question: one short question to understand better if intent is unclear, otherwise empty.
LANG is en, hi (Devanagari) or hg (Hinglish in Roman letters)."""

# Hamare pakke (verified) steps. Inhe Dost 3 official sites se match karegi.
S = {
 "save":  {"en": "Save screenshots showing the link, date and time.", "hi": "लिंक, तारीख और समय दिखाते हुए स्क्रीनशॉट सेव करें।", "hg": "Link, date aur time dikhte hue screenshot save karo."},
 "nopay": {"en": "Do not send any money.", "hi": "कोई पैसा न भेजें।", "hg": "Koi paisa mat bhejo."},
 "nodel": {"en": "Do not delete chats or photos.", "hi": "चैट या फोटो डिलीट न करें।", "hg": "Chat ya photo delete mat karo."},
 "block": {"en": "Take screenshots before you block the person.", "hi": "ब्लॉक करने से पहले स्क्रीनशॉट ले लें।", "hg": "Block karne se pehle screenshot le lo."},
 "report": {"en": "Report the content on the platform itself.", "hi": "प्लेटफॉर्म पर ही कंटेंट रिपोर्ट करें।", "hg": "Platform par hi content report karo."},
 "trust": {"en": "Tell someone you trust.", "hi": "किसी भरोसेमंद इंसान को बताएं।", "hg": "Kisi bharose ke insaan ko batao."},
}
STEPS = {"blackmail": ["save", "nopay", "nodel"], "morph": ["save", "report", "nodel"],
         "stalk": ["save", "block", "trust"], "fake": ["save", "report"]}
PAGE = {"blackmail": "/action-plan.html", "morph": "/content.html", "stalk": "/complaint.html",
        "fake": "/content.html", "anonymous": "/anonymous.html", "track": "/track.html"}
MORE = {"en": "More help:", "hi": "आगे की मदद:", "hg": "Aage ki madad:"}
HELP = {"en": "In danger: call 100. Women helpline 181. Cyber helpline 1930.",
        "hi": "खतरे में हों तो 100 पर कॉल करें। महिला हेल्पलाइन 181, साइबर हेल्पलाइन 1930।",
        "hg": "Khatre me ho to 100 par call karo. Women helpline 181, Cyber helpline 1930."}
WARM = {"en": "I am sorry you are going through this. You are not alone.", "hi": "मुझे अफ़सोस है कि आप इससे गुज़र रही हैं। आप अकेली नहीं हैं।", "hg": "Mujhe afsos hai ki tum isse guzar rahi ho. Tum akeli nahi ho."}
ASK = {"en": "What is happening: blackmail, a photo, someone following you, or a fake profile?",
       "hi": "क्या हो रहा है: ब्लैकमेल, फोटो, कोई पीछा कर रहा है, या फर्जी प्रोफाइल?",
       "hg": "Kya ho raha hai: blackmail, photo, koi peecha kar raha hai, ya fake profile?"}
FIXED = {
 "danger": {"en": "If you are in danger right now, call 100 immediately and move to a safe place near people. Women helpline: 181.",
            "hi": "अगर आप अभी खतरे में हैं, तो तुरंत 100 पर कॉल करें और लोगों के पास किसी सुरक्षित जगह पहुँचें। महिला हेल्पलाइन: 181।",
            "hg": "Agar tum abhi khatre me ho, to turant 100 par call karo aur logon ke paas kisi safe jagah pahuncho. Women helpline: 181."},
 "selfharm": {"en": "I am so sorry you are in this much pain. Please tell someone you trust right now, or call 100 if you are in immediate danger. You matter.",
              "hi": "मुझे बहुत अफ़सोस है कि आप इतने दर्द में हैं। कृपया अभी किसी भरोसेमंद इंसान को बताएं, या तुरंत खतरे में हों तो 100 पर कॉल करें। आप मायने रखती हैं।",
              "hg": "Mujhe bahut afsos hai ki tum itne dard me ho. Please abhi kisi bharose ke insaan ko batao, ya turant khatre me ho to 100 par call karo. Tum matter karti ho."},
}
KEYS = [
 ("selfharm", ["suicide", "kill myself", "end my life", "marna chahti", "jeena nahi", "आत्महत्या", "मरना चाहती"]),
 ("danger", ["jaan se", "maar dega", "maar dunga", "bachao", "khatre", "danger", "जान से", "खतरे"]),
 ("blackmail", ["blackmail", "ब्लैकमेल", "paise", "paisa", "dhamki", "dhamk", "threat", "पैसे", "धमकी"]),
 ("morph", ["morph", "photo", "viral", "deepfake", "फोटो", "वायरल"]),
 ("stalk", ["peecha", "follow", "stalk", "baar baar", "पीछा"]),
 ("fake", ["fake profile", "fake account", "फर्जी"]),
 ("anonymous", ["anonymous", "naam nahi", "gumnam", "गुमनाम"]),
 ("track", ["track", "status", "ट्रैक"]),
]
BAD = re.compile(r"(https?://|www\.|\d|section|\bipc\b|\bbns\b|धारा|dhara|guarantee)", re.I)


def clean(t):
    t = str(t or "").strip()
    return "" if (len(t) > 400 or BAD.search(t)) else t


def detect(text):
    t = text.lower()
    for intent, words in KEYS:
        if any(w in t for w in words):
            return intent
    return "unclear"


def ask_ai(messages, lang):
    key = os.environ.get("ANTHROPIC_API_KEY")
    if not key:
        return None
    body = {"model": os.environ.get("RAAH_MODEL", "claude-haiku-5-5"), "max_tokens": 300,
            "system": SYSTEM + "\nLANG: " + lang, "messages": messages}
    req = urllib.request.Request(
        "https://api.anthropic.com/v1/messages", data=json.dumps(body).encode(),
        headers={"x-api-key": key, "anthropic-version": "2023-06-01", "content-type": "application/json"})
    try:
        with urllib.request.urlopen(req, timeout=30) as r:
            return json.loads(r.read())["content"][0]["text"]
    except Exception as e:
        print("AI error:", e)
        return None


def parse_ai(raw):
    try:
        d = json.loads(re.sub(r"^```(?:json)?|```$", "", raw.strip(), flags=re.M).strip())
        return (d.get("intent") if d.get("intent") in INTENTS else "unclear"), clean(d.get("message")), clean(d.get("question"))
    except Exception:
        return None


def compose(intent, msg, q, lang):
    if intent in FIXED:
        return FIXED[intent][lang]
    parts = [msg or WARM[lang]]
    if intent == "unclear":
        parts.append(q or ASK[lang])
    else:
        steps = [S[k][lang] for k in STEPS.get(intent, [])]
        if steps:
            parts.append("\n".join("%d. %s" % (i, t) for i, t in enumerate(steps, 1)))
        if PAGE.get(intent):
            parts.append(MORE[lang] + " " + PAGE[intent])
    parts.append(HELP[lang])
    return "\n\n".join(parts)


@app.post("/api/agent")
def agent():
    d = request.get_json(force=True, silent=True) or {}
    lang = d.get("lang") if d.get("lang") in HELP else "hg"
    msgs = [{"role": m["role"], "content": str(m.get("content", ""))[:1000]}
            for m in (d.get("messages") or [])[-8:]
            if isinstance(m, dict) and m.get("role") in ("user", "assistant") and m.get("content")]
    while msgs and msgs[0]["role"] != "user":
        msgs.pop(0)
    if not msgs:
        return jsonify(reply=HELP[lang], ai=False)
    kw = detect(msgs[-1]["content"])
    if kw in ("danger", "selfharm"):                 # jaan ka khatra: AI ko poochhe bina fixed jawab
        return jsonify(reply=FIXED[kw][lang], ai=False)
    raw = ask_ai(msgs, lang)
    parsed = parse_ai(raw) if raw else None
    if parsed:
        intent, msg, q = parsed
        if intent == "unclear" and kw != "unclear":
            intent = kw
        return jsonify(reply=compose(intent, msg, q, lang), ai=True)
    return jsonify(reply=compose(kw, "", "", lang), ai=False)


init_db()
if __name__ == "__main__":
    app.run(debug=True)
