// Raah - i18n.js: Language option (English / Hindi / Hinglish) + floating AI helper button.
// Hinglish = jo text HTML me pehle se likha hai. English aur Hindi neeche D me hain.
(function () {
  var D = {
    en: {
      sos_d: "In danger:", sos_w: "Women helpline:", sos_c: "Cyber helpline:", exit: "Quick exit", back: "Back",
      fab: "Need help? Ask AI",
      h_title: "What do you want?",
      h_lead: "Is someone harassing you online? Choose the path you are comfortable with. No hurry, nothing forced.",
      r1_t: "I just want a photo or content removed", r1_d: "No police, no name. A way to get content removed from platforms.",
      r2_t: "I want to complain, but not give my name", r2_d: "When an anonymous report is possible and when it is not, stated clearly.",
      r3_t: "I want justice: a full complaint", r3_d: "A timeline from your chat and a complaint draft, ready for an FIR.",
      help_t: "Not sure where to start?", help_p: "The first 10 minutes matter most. Read this first.", help_b: "First 10 minutes plan",
      ai_t: "Talk to the AI helper", trk_t: "Track my report", priv_t: "Your privacy",
      content_h1: "Getting content removed", anon_h1: "Complaint without a name", comp_h1: "Prepare a full complaint",
      plan_h1: "What to do in the first 10 minutes", res_h1: "Your timeline and draft",
      trk_h1: "Track your report", trk_lead: "Save your report here and update its status yourself. We store no name or number.",
      trk_new: "New report", trk_cat: "What happened?", trk_plat: "Which platform?", trk_note: "Short note (no name or number)",
      trk_save: "Create tracking ID", trk_find: "Already have an ID?", trk_look: "Look up", trk_upd: "Update status", trk_hist: "History",
      trk_warn: "Keep your ID safe. Anyone who has it can see this record.",
      cat_blackmail: "Blackmail or money threat", cat_morph: "Morphed photo or video", cat_stalk: "Stalking or repeated harassment", cat_fake: "Fake profile", cat_other: "Something else",
      ag_h1: "AI helper", ag_lead: "Tell me what happened. I will help you reach the right page.",
      ag_warn: "This chat goes to an AI service. Do not write names, phone numbers or addresses. It is a guide, not legal advice.",
      ag_ph: "Type your message", ag_send: "Send", ag_hello: "Hi. Tell me what happened, in your own words.",
      prepared: "Prepared", sent: "Sent", replied: "Reply received", removed: "Content removed", escalated: "Escalated",
      saved: "Saved. Your ID:", notfound: "This ID was not found.", err: "Something went wrong. Try again.", wait: "Replying...", noai: "(AI is off, basic guidance)"
    },
    hi: {
      sos_d: "खतरे में:", sos_w: "महिला हेल्पलाइन:", sos_c: "साइबर हेल्पलाइन:", exit: "तुरंत बाहर", back: "वापस",
      fab: "मदद चाहिए? AI से पूछें",
      h_title: "आप क्या चाहती हैं?",
      h_lead: "क्या कोई आपको ऑनलाइन परेशान कर रहा है? जो रास्ता ठीक लगे वही चुनें। कोई जल्दी नहीं, कोई ज़बरदस्ती नहीं।",
      r1_t: "मुझे बस फोटो या कंटेंट हटवाना है", r1_d: "पुलिस नहीं, नाम नहीं। प्लेटफॉर्म से कंटेंट हटवाने का रास्ता।",
      r2_t: "शिकायत करनी है, पर नाम नहीं देना", r2_d: "गुमनाम रिपोर्ट कब हो सकती है और कब नहीं, साफ़ साफ़।",
      r3_t: "मुझे न्याय चाहिए, पूरी शिकायत", r3_d: "चैट से सबूत की टाइमलाइन और शिकायत का ड्राफ्ट, FIR के लिए तैयार।",
      help_t: "समझ नहीं आ रहा कहाँ से शुरू करें?", help_p: "शुरू के 10 मिनट सबसे ज़रूरी होते हैं। पहले यह पढ़ें।", help_b: "पहले 10 मिनट का प्लान",
      ai_t: "AI सहायक से बात करें", trk_t: "मेरी रिपोर्ट ट्रैक करें", priv_t: "आपकी प्राइवेसी",
      content_h1: "कंटेंट हटवाना", anon_h1: "बिना नाम की शिकायत", comp_h1: "पूरी शिकायत तैयार करें",
      plan_h1: "पहले 10 मिनट में क्या करें", res_h1: "आपकी टाइमलाइन और ड्राफ्ट",
      trk_h1: "अपनी रिपोर्ट ट्रैक करें", trk_lead: "अपनी रिपोर्ट यहाँ सेव करें और स्टेटस खुद अपडेट करें। हम कोई नाम या नंबर सेव नहीं करते।",
      trk_new: "नई रिपोर्ट", trk_cat: "क्या हुआ?", trk_plat: "कौन सा प्लेटफॉर्म?", trk_note: "छोटा नोट (नाम या नंबर नहीं)",
      trk_save: "ट्रैकिंग ID बनाएं", trk_find: "पहले से ID है?", trk_look: "खोजें", trk_upd: "स्टेटस बदलें", trk_hist: "इतिहास",
      trk_warn: "ID संभालकर रखें। जिसके पास ID है वह यह रिकॉर्ड देख सकता है।",
      cat_blackmail: "ब्लैकमेल या पैसों की धमकी", cat_morph: "फोटो या वीडियो से छेड़छाड़", cat_stalk: "पीछा करना या बार-बार परेशान करना", cat_fake: "फर्जी प्रोफाइल", cat_other: "कुछ और",
      ag_h1: "AI सहायक", ag_lead: "बताइए क्या हुआ। आपको सही पेज तक पहुँचाने में मदद मिलेगी।",
      ag_warn: "यह चैट एक AI सेवा को जाती है। नाम, फोन नंबर या पता न लिखें। यह गाइड है, कानूनी सलाह नहीं।",
      ag_ph: "अपना संदेश लिखें", ag_send: "भेजें", ag_hello: "नमस्ते। अपने शब्दों में बताइए क्या हुआ।",
      prepared: "तैयार", sent: "भेजा गया", replied: "जवाब आया", removed: "कंटेंट हट गया", escalated: "आगे बढ़ाया",
      saved: "सेव हो गया। आपकी ID:", notfound: "यह ID नहीं मिली।", err: "कुछ गड़बड़ हुई, दोबारा कोशिश करें।", wait: "जवाब आ रहा है...", noai: "(AI बंद है, बुनियादी जानकारी)"
    }
  };
  // Hinglish: sirf JS se bane text ke liye (baaki HTML me pehle se likha hai)
  var HG = {
    ag_hello: "Namaste. Apne shabdon me batao kya hua.", prepared: "Taiyaar", sent: "Bheja gaya", replied: "Jawab aaya",
    removed: "Content hat gaya", escalated: "Escalate kiya", saved: "Save ho gaya. Tumhari ID:", notfound: "Ye ID nahi mili.",
    err: "Kuch gadbad hui, dobara try karo.", wait: "Jawab aa raha hai...", noai: "(AI band hai, basic jaankari)",
    fab: "Madad chahiye? AI se pucho", ag_ph: "Apna message likho"
  };

  function get() { try { return localStorage.getItem("raah_lang") || "hg"; } catch (e) { return "hg"; } }
  function set(l) { try { localStorage.setItem("raah_lang", l); } catch (e) {} }
  window.RaahLang = get;
  window.T = function (k) { var l = get(); return l === "hg" ? (HG[k] || (D.en[k] || k)) : (D[l][k] || k); };

  function apply() {
    var l = get();
    document.documentElement.lang = l === "hi" ? "hi" : (l === "en" ? "en" : "hi-Latn");
    document.querySelectorAll("[data-i18n]").forEach(function (el) {
      if (el.dataset.orig === undefined) el.dataset.orig = el.textContent;
      el.textContent = l === "hg" ? el.dataset.orig : (D[l][el.dataset.i18n] || el.dataset.orig);
    });
    document.querySelectorAll("[data-i18n-ph]").forEach(function (el) {
      if (el.dataset.orig === undefined) el.dataset.orig = el.placeholder;
      el.placeholder = l === "hg" ? el.dataset.orig : (D[l][el.dataset.i18nPh] || el.dataset.orig);
    });
    var fab = document.getElementById("raah-fab");
    if (fab) fab.textContent = "\uD83D\uDCAC " + T("fab");
    document.dispatchEvent(new Event("langchange"));
  }

  var sos = document.querySelector(".sos");
  if (sos) {
    var wrap = document.createElement("label");
    wrap.className = "langsel";
    var sel = document.createElement("select");
    sel.setAttribute("aria-label", "Language");
    [["hg", "Hinglish"], ["hi", "\u0939\u093F\u0928\u094D\u0926\u0940"], ["en", "English"]].forEach(function (o) {
      var op = document.createElement("option"); op.value = o[0]; op.textContent = o[1]; sel.appendChild(op);
    });
    sel.value = get();
    sel.addEventListener("change", function () { set(sel.value); apply(); });
    wrap.appendChild(sel);
    sos.insertBefore(wrap, document.getElementById("quick-exit"));
  }
  if (!/agent\.html$/.test(location.pathname)) {
    var a = document.createElement("a");
    a.id = "raah-fab"; a.className = "fab"; a.href = "agent.html";
    document.body.appendChild(a);
  }
  apply();
})();
