// Raah - script.js
// Sirf ek kaam: "Quick exit" (Esc 2 baar dabao ya button dabao).
// Ye isliye zaroori hai ki agar koi ladki ke aas-paas ho to wo turant page chhod sake.
(function () {
  function leave() {
    // replace() se back button dabane par ye page wapas nahi aata
    window.location.replace("https://www.google.com");
  }
  var exitBtn = document.getElementById("quick-exit");
  if (exitBtn) {
    exitBtn.addEventListener("click", function (e) { e.preventDefault(); leave(); });
  }
  var last = 0;
  document.addEventListener("keydown", function (e) {
    if (e.key !== "Escape") return;
    var now = Date.now();
    if (now - last < 600) leave();
    last = now;
  });
})();
